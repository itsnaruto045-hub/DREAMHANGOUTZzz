const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'transfer',
  aliases: ['pay', 'give'],
  description: 'Transfer credits to another user (currently disabled)',
  execute(message, args, client) {
    const embed = new EmbedBuilder()
      .setColor('#E74C3C')
      .setTitle('🚫 Transfer Disabled')
      .setDescription('Credit transfers are currently disabled.')
      .setFooter({ text: `Requested by ${message.author.tag}` });
    
    message.reply({ embeds: [embed] });
  }
};
