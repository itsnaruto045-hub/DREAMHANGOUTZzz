const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'shop',
  description: 'Browse the credit shop',
  execute(message, args, client) {
    const items = client.db.getShopItems(message.guild.id);
    
    if (items.length === 0) {
      const embed = new EmbedBuilder()
        .setColor('#E74C3C')
        .setTitle('🛒 Credit Shop')
        .setDescription('The shop is empty! An admin needs to add items using `+shopsetup`')
        .setFooter({ text: `Requested by ${message.author.tag}` });
      
      return message.reply({ embeds: [embed] });
    }
    
    const balance = client.db.getBalance(message.guild.id, message.author.id);
    
    let description = '';
    for (const item of items) {
      const stock = item.stock === -1 ? '∞' : item.stock;
      description += `**${item.item_id}** - ${item.name}\n`;
      description += `   💰 ${item.price.toLocaleString()} credits | 📦 Stock: ${stock}\n`;
      if (item.description) {
        description += `   📝 ${item.description}\n`;
      }
      description += '\n';
    }
    
    const embed = new EmbedBuilder()
      .setColor('#9B59B6')
      .setTitle('🛒 Credit Shop')
      .setDescription(description)
      .addFields({ name: 'Your Balance', value: `${balance.toLocaleString()} credits`, inline: true })
      .setFooter({ text: 'Use +buy <item_id> to purchase' })
      .setTimestamp();
    
    message.reply({ embeds: [embed] });
  }
};
